from project.hero import Hero


class Wizard(Hero):
	pass